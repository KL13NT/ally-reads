module.exports = {
	verbose: true,
	globals: {
		window: true
	}
}